package com.example.supermarketapplication.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.supermarketapplication.R;
import com.example.supermarketapplication.activitys.MainActivity;
import com.example.supermarketapplication.activitys.UserData;

import java.util.List;

public class RegisterFragment extends Fragment {

    private List<UserData> userDataList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_register, container, false);

        // Get userDataList from MainActivity
        MainActivity mainActivity = (MainActivity) getActivity();
        if (mainActivity != null) {
            userDataList = mainActivity.getUserDataList();
        }

        Button buttonRegToMarket = view.findViewById(R.id.btnRegister);
        buttonRegToMarket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editTxtUserName = view.findViewById(R.id.editTxtUser);
                String userName = editTxtUserName.getText().toString();

                EditText editTxtPassword = view.findViewById(R.id.editTxtPass);
                String password = editTxtPassword.getText().toString();

                EditText editTxtPhone = view.findViewById(R.id.editTxtPhone);
                String phone = editTxtPhone.getText().toString();

                registerUser(userName, password, phone);
            }
        });

        return view;
    }

    private void registerUser(String userName, String password, String phone) {
        // Check if the username already exists
        boolean userExists = false;
        for (UserData userData : userDataList) {
            if (userData.getUserName().equals(userName)) {
                Toast.makeText(getContext(), "Username already exists", Toast.LENGTH_SHORT).show();
                userExists = true;
                break;
            }
        }

        if (!userExists) {
            UserData newUser = new UserData(userName, password, phone);
            userDataList.add(newUser);
            Toast.makeText(getContext(), "User registered successfully", Toast.LENGTH_SHORT).show();

            Bundle bundle = new Bundle();
            bundle.putString("UserName", userName);
            Navigation.findNavController(requireView()).navigate(R.id.action_registerFragment_to_marketFragment, bundle);
        }
    }
}