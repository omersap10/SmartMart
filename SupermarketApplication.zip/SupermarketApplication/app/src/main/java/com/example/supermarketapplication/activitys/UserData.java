package com.example.supermarketapplication.activitys;

public class UserData
{
    private String UserName;
    private String Password;
    private String Phone;

    public UserData(String userName, String password, String phone) {
        UserName = userName;
        Password = password;
        Phone = phone;
    }

    public String getPhone()
    {
        return Phone;
    }

    public void setPhone(String phone)
    {
        Phone = phone;
    }

    public String getUserName()
    {
        return UserName;
    }

    public void setUserName(String userName)
    {
        UserName = userName;
    }

    public String getPassword()
    {
        return Password;
    }

    public void setPassword(String password)
    {
        Password = password;
    }
}
