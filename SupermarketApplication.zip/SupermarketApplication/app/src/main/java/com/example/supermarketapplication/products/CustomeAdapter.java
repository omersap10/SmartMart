package com.example.supermarketapplication.products;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.supermarketapplication.R;

import java.util.ArrayList;

public class CustomeAdapter extends RecyclerView.Adapter<CustomeAdapter.MyViewHolder> {

    private ArrayList<ProductsData> dataset;
    private int[] productQuantities;

    public CustomeAdapter(ArrayList<ProductsData> dataSet, int[] productQuantities) {
        this.dataset = dataSet;
        this.productQuantities = productQuantities;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView textViewProductName;
        ImageView imageView;
        TextView txtQuantity;
        Button btnAdd;
        Button btnRemove;

        public MyViewHolder(View itemView) {
            super(itemView);

            textViewProductName = itemView.findViewById(R.id.txtViewProduct);
            imageView = itemView.findViewById(R.id.imageView);
            txtQuantity = itemView.findViewById(R.id.txtQuantity);
            btnAdd = itemView.findViewById(R.id.btnAdd);
            btnRemove = itemView.findViewById(R.id.btnRemove);
        }
    }

    @NonNull
    @Override
    public CustomeAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardrow, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomeAdapter.MyViewHolder holder, int position) {
        TextView textViewName = holder.textViewProductName;
        ImageView imageView = holder.imageView;
        TextView txtQuantity = holder.txtQuantity;
        Button btnAdd = holder.btnAdd;
        Button btnRemove = holder.btnRemove;

        textViewName.setText(dataset.get(position).getProductName());
        imageView.setImageResource(dataset.get(position).getImage());

        txtQuantity.setText("Quantity: " + productQuantities[position]);

        btnAdd.setOnClickListener(v -> {
            productQuantities[position]++;
            txtQuantity.setText("Quantity: " + productQuantities[position]);
        });

        btnRemove.setOnClickListener(v -> {
            if (position >= 0 && position < productQuantities.length) {
                if (productQuantities[position] > 0) {
                    productQuantities[position]--;
                    txtQuantity.setText("Quantity: " + productQuantities[position]);
                } else {
                    Toast.makeText(v.getContext(), "Quantity cannot be negative", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(v.getContext(), "Invalid position", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataset.size();
    }
}
