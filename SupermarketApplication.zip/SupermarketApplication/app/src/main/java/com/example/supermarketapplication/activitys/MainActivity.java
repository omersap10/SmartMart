package com.example.supermarketapplication.activitys;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.example.supermarketapplication.R;
import com.example.supermarketapplication.fragments.LoginFragment;
import com.example.supermarketapplication.fragments.MarketFragment;
import com.example.supermarketapplication.fragments.RegisterFragment;
import com.example.supermarketapplication.products.CustomeAdapter;
import com.example.supermarketapplication.products.MyData;
import com.example.supermarketapplication.products.ProductsData;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
{
    public List<UserData> userDataList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public List<UserData> getUserDataList() {
        return userDataList;
    }

}
