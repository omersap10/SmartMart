package com.example.supermarketapplication.products;

public class ProductsData
{
    private String productName;
    private int id;
    private int image;

    public ProductsData(String productName, int id, int image) {
        this.productName = productName;
        this.id = id;
        this.image = image;
    }

    public String getProductName()
    {
        return productName;
    }
    public void setProductName(String name)
    {
        this.productName = name;
    }
    public int getId()
    {
        return id;
    }
    public int getImage()
    {
        return image;
    }
    public void setImage(int image)
    {
        this.image = image;
    }
}
