package com.example.supermarketapplication.products;

import com.example.supermarketapplication.R;

public class MyData
{

    public static String[] productNameArray = {"Apple", "Bread", "Cabbage", "Carrot", "Cheese",
            "Chocolate", "Meat", "Potato", "Snack", "Tomato"};

    public static Integer[] drawableArray = {R.drawable.apple, R.drawable.bread, R.drawable.cabbage, R.drawable.carrot,
        R.drawable.cheese, R.drawable.chocolate, R.drawable.meat, R.drawable.potato, R.drawable.snack, R.drawable.tomato};

    public static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
}
