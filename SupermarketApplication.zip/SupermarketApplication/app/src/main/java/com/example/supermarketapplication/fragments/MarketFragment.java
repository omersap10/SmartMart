package com.example.supermarketapplication.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.supermarketapplication.R;
import com.example.supermarketapplication.activitys.MainActivity;
import com.example.supermarketapplication.products.CustomeAdapter;
import com.example.supermarketapplication.products.MyData;
import com.example.supermarketapplication.products.ProductsData;

import java.util.ArrayList;

public class MarketFragment extends Fragment {

    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private ArrayList<ProductsData> dataSet;
    private CustomeAdapter adapter;
    private int[] productQuantities = new int[10];
    MainActivity mainActivity = (MainActivity)getActivity();


    public MarketFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            dataSet = new ArrayList<>();
            for (int i = 0; i < MyData.drawableArray.length; i++) {
                dataSet.add(new ProductsData(
                        MyData.productNameArray[i],
                        MyData.id_[i],
                        MyData.drawableArray[i]
                ));
            }
            adapter = new CustomeAdapter(dataSet,productQuantities);
         //   resetProductQuantities();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_market, container, false);
        String UserName = getArguments().getString("UserName");
        ((android.widget.TextView) view.findViewById(R.id.txtViewUserName)).setText(UserName);

        recyclerView = view.findViewById(R.id.recView);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);

        return view;

    }
}
